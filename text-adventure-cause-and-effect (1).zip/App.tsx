import React, { useState } from 'react';
import GameScreen from './components/GameScreen';
import * as soundService from './services/soundService';

const App: React.FC = () => {
  const [gameStarted, setGameStarted] = useState(false);

  const handleStartGame = () => {
    soundService.playStartGameSound();
    setGameStarted(true);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-sans flex flex-col items-center justify-center p-4">
      <header className="w-full max-w-6xl text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-emerald-400 font-serif tracking-wider">
          Gemini Text Adventure
        </h1>
        <p className="text-slate-400 mt-2">Your story, imagined by AI.</p>
      </header>

      <main className="w-full max-w-6xl flex-grow">
        {gameStarted ? (
          <GameScreen />
        ) : (
          <div className="flex flex-col items-center justify-center h-full bg-slate-800/50 rounded-lg p-8">
            <h2 className="text-3xl font-semibold mb-4 text-center">Welcome, Adventurer!</h2>
            <p className="text-slate-300 mb-8 max-w-2xl text-center">
              You are about to enter a world crafted entirely by Gemini. Every scene, every outcome, and every image is generated on the fly. Your journey is unique. Are you ready to begin?
            </p>
            <button
              onClick={handleStartGame}
              className="px-8 py-4 bg-emerald-600 text-white font-bold rounded-lg shadow-lg hover:bg-emerald-500 transform hover:scale-105 transition-all duration-300"
            >
              Start New Adventure
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;