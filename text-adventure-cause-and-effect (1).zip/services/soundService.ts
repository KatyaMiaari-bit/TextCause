// A simple wrapper around the Web Audio API to play sounds.
// This avoids needing to manage <audio> elements or load external files for simple UI feedback.
const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();

const playNote = (frequency: number, duration: number, volume: number = 0.5, type: OscillatorType = 'sine') => {
  if (!audioContext || audioContext.state === 'suspended') {
    audioContext.resume();
  }
  
  if (!audioContext) return;

  try {
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
    gainNode.gain.setValueAtTime(volume, audioContext.currentTime);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + duration);
  } catch (e) {
    console.error("Could not play sound.", e);
  }
};

export const playStartGameSound = () => {
  playNote(440, 0.1, 0.3, 'triangle'); // A4
  setTimeout(() => playNote(523.25, 0.1, 0.3, 'triangle'), 100); // C5
  setTimeout(() => playNote(659.25, 0.2, 0.3, 'triangle'), 200); // E5
};

export const playImageLoadSound = () => {
  playNote(300, 0.05, 0.2, 'square');
  setTimeout(() => playNote(400, 0.05, 0.2, 'square'), 50);
  setTimeout(() => playNote(500, 0.05, 0.2, 'square'), 100);
  setTimeout(() => playNote(600, 0.05, 0.2, 'square'), 150);
};

export const playErrorSound = () => {
  playNote(220, 0.2, 0.4, 'sawtooth');
};

export const playKeyClickSound = () => {
  playNote(800, 0.02, 0.1, 'sine');
};

export const playSubmitSound = () => {
  playNote(600, 0.1, 0.3, 'square');
};
