
import React, { useRef, useEffect } from 'react';
import type { StorySegment } from '../types';

interface StoryLogProps {
  log: StorySegment[];
  isGenerating: boolean;
}

const StoryLog: React.FC<StoryLogProps> = ({ log, isGenerating }) => {
  const endOfLogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endOfLogRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [log, isGenerating]);

  const getSegmentClasses = (type: StorySegment['type']) => {
    switch (type) {
      case 'user':
        return 'bg-slate-700/50 text-emerald-300 italic self-end';
      case 'game':
        return 'bg-slate-900/50 text-slate-300';
      case 'error':
        return 'bg-red-900/50 text-red-300';
      default:
        return 'bg-gray-700';
    }
  };

  return (
    <div className="flex-grow overflow-y-auto mb-4 p-2 custom-scrollbar pr-4">
      <div className="flex flex-col gap-4">
        {log.map((segment) => (
          segment.type === 'user' && segment.content === 'Begin the adventure.' ? null : (
            <div
              key={segment.id}
              className={`p-4 rounded-lg max-w-[90%] whitespace-pre-wrap font-serif ${getSegmentClasses(segment.type)}`}
            >
              {segment.type === 'user' && <span className="font-bold text-emerald-400 not-italic mr-2">&gt;</span>}
              {segment.content}
            </div>
          )
        ))}
        {isGenerating && (
          <div className="p-4 rounded-lg bg-slate-900/50 text-slate-400 self-start animate-pulse">
            Thinking...
          </div>
        )}
        <div ref={endOfLogRef} />
      </div>
    </div>
  );
};

export default StoryLog;
