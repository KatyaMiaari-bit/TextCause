import React, { useEffect, useReducer, useCallback, useRef } from 'react';
import type { StorySegment, GameState, GameAction } from '../types';
import { generateStorySegment, generateSceneImage } from '../services/geminiService';
import * as soundService from '../services/soundService';
import { usePrevious } from '../hooks/usePrevious';
import StoryLog from './StoryLog';
import ActionInput from './ActionInput';
import ImageDisplay from './ImageDisplay';

const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'START_GENERATION':
      return {
        ...state,
        storyLog: [...state.storyLog, action.payload],
        isGenerating: true,
        error: null,
      };
    case 'STORY_SUCCESS':
      return {
        ...state,
        storyLog: [...state.storyLog, action.payload],
        isGenerating: false,
      };
    case 'IMAGE_LOADING':
      return {
        ...state,
        isImageLoading: true,
      };
    case 'IMAGE_SUCCESS':
      return {
        ...state,
        currentImage: action.payload,
        isImageLoading: false,
      };
    case 'GENERATION_ERROR':
      return {
        ...state,
        isGenerating: false,
        isImageLoading: false,
        error: action.payload,
        storyLog: [...state.storyLog, { id: Date.now(), type: 'error', content: action.payload }]
      };
    default:
      return state;
  }
};

const initialState: GameState = {
  storyLog: [],
  currentImage: null,
  isGenerating: false,
  isImageLoading: false,
  error: null,
};

const GameScreen: React.FC = () => {
  const [state, dispatch] = useReducer(gameReducer, initialState);
  const prevState = usePrevious(state);
  const typingIntervalRef = useRef<number | null>(null);

  // Effect for handling sound triggers based on state changes
  useEffect(() => {
    // Play image loading sound
    if (state.isImageLoading && !prevState?.isImageLoading) {
      soundService.playImageLoadSound();
    }
    // Play error sound
    if (state.error && state.error !== prevState?.error) {
      soundService.playErrorSound();
    }
  }, [state, prevState]);

  // Effect for handling the continuous typing sound
  useEffect(() => {
    const isAiResponding = state.isGenerating && !state.isImageLoading;
    
    if (isAiResponding) {
      // Start typing sound
      typingIntervalRef.current = window.setInterval(() => {
        soundService.playKeyClickSound();
      }, 180);
    } else {
      // Stop typing sound
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
        typingIntervalRef.current = null;
      }
    }

    // Cleanup on unmount
    return () => {
      if (typingIntervalRef.current) {
        clearInterval(typingIntervalRef.current);
      }
    };
  }, [state.isGenerating, state.isImageLoading]);


  const processTurn = useCallback(async (log: StorySegment[]) => {
    try {
      const { storyText, imagePrompt } = await generateStorySegment(log);
      dispatch({ type: 'STORY_SUCCESS', payload: { id: Date.now(), type: 'game', content: storyText } });
      dispatch({ type: 'IMAGE_LOADING' });

      try {
        const imageUrl = await generateSceneImage(imagePrompt);
        dispatch({ type: 'IMAGE_SUCCESS', payload: imageUrl });
      } catch (imageError) {
        const errorMessage = imageError instanceof Error ? imageError.message : "Unknown image error.";
        dispatch({ type: 'GENERATION_ERROR', payload: errorMessage });
      }
    } catch (storyError) {
      const errorMessage = storyError instanceof Error ? storyError.message : "Unknown story error.";
      dispatch({ type: 'GENERATION_ERROR', payload: errorMessage });
    }
  }, []);


  useEffect(() => {
    const startNewGame = async () => {
        const initialSegment: StorySegment = {
            id: Date.now(),
            type: 'user',
            content: "Begin the adventure."
        };
        dispatch({ type: 'START_GENERATION', payload: initialSegment });
        await processTurn([initialSegment]);
    };
    
    startNewGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePlayerAction = async (action: string) => {
    if (!action.trim() || state.isGenerating) return;
    soundService.playSubmitSound();
    const userAction: StorySegment = { id: Date.now(), type: 'user', content: action };
    const newLog = [...state.storyLog, userAction];
    dispatch({ type: 'START_GENERATION', payload: userAction });
    await processTurn(newLog);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 h-[calc(100vh-150px)]">
      <div className="lg:col-span-2 h-full">
        <ImageDisplay 
          src={state.currentImage} 
          isLoading={state.isImageLoading} 
          alt="Current scene"
        />
      </div>
      <div className="lg:col-span-3 h-full flex flex-col bg-slate-800/70 rounded-lg shadow-2xl p-4">
        <StoryLog log={state.storyLog} isGenerating={state.isGenerating} />
        <ActionInput onSubmit={handlePlayerAction} disabled={state.isGenerating} />
      </div>
    </div>
  );
};

export default GameScreen;