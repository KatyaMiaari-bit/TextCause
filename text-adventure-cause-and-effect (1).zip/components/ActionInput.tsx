import React, { useState, useRef, useEffect } from 'react';
import * as soundService from '../services/soundService';

interface ActionInputProps {
  onSubmit: (action: string) => void;
  disabled: boolean;
}

// Check for the browser's SpeechRecognition API
// FIX: Cast `window` to `any` to access the non-standard `SpeechRecognition` property.
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
const isSpeechRecognitionSupported = !!SpeechRecognition;

const ActionInput: React.FC<ActionInputProps> = ({ onSubmit, disabled }) => {
  const [inputValue, setInputValue] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  // FIX: Use `any` for the SpeechRecognition instance type as it's non-standard and the local `SpeechRecognition` constant shadows the global type.
  const recognitionRef = useRef<any | null>(null);

  const handleMicClick = () => {
    if (!isSpeechRecognitionSupported) {
      alert("Sorry, your browser doesn't support speech recognition.");
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
    } else {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsRecording(true);
        setInputValue(''); // Clear input when starting to record
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        alert(`Speech recognition error: ${event.error}`);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };
      
      recognition.start();
      recognitionRef.current = recognition;
    }
  };

  useEffect(() => {
    // Cleanup function to stop recognition if the component unmounts
    return () => {
      recognitionRef.current?.abort();
    };
  }, []);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSubmit(inputValue);
      setInputValue('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center gap-2 mt-auto">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        disabled={disabled}
        placeholder={disabled ? "Awaiting story..." : isRecording ? "Listening..." : "What do you do next?"}
        className="flex-grow bg-slate-900 border border-slate-700 text-slate-200 rounded-md p-3 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition disabled:opacity-50"
        aria-label="Your action"
      />
      {isSpeechRecognitionSupported && (
         <button
            type="button"
            onClick={handleMicClick}
            disabled={disabled}
            className={`p-3 h-full rounded-md transition ${
               isRecording 
               ? 'bg-red-600 hover:bg-red-500 text-white animate-pulse' 
               : 'bg-blue-600 hover:bg-blue-500 text-white'
            } disabled:bg-slate-600 disabled:cursor-not-allowed`}
            aria-label={isRecording ? 'Stop recording' : 'Start recording oral response'}
         >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
         </button>
      )}
      <button
        type="submit"
        disabled={disabled || isRecording}
        className="bg-emerald-600 text-white font-bold rounded-md p-3 h-full hover:bg-emerald-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition"
        aria-label="Submit action"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
      </button>
    </form>
  );
};

export default ActionInput;