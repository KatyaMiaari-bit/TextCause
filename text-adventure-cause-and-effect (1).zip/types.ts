
export interface StorySegment {
  id: number;
  type: 'user' | 'game' | 'error';
  content: string;
}

export interface GameState {
  storyLog: StorySegment[];
  currentImage: string | null;
  isGenerating: boolean;
  isImageLoading: boolean;
  error: string | null;
}

export type GameAction =
  | { type: 'START_GENERATION'; payload: StorySegment }
  | { type: 'STORY_SUCCESS'; payload: StorySegment }
  | { type: 'IMAGE_SUCCESS'; payload: string }
  | { type: 'IMAGE_LOADING' }
  | { type: 'GENERATION_ERROR'; payload: string };
