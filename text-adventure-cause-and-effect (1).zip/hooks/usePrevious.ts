import { useRef, useEffect } from 'react';

/**
 * Custom hook to store the previous value of a state or prop.
 * @param value The current value.
 * @returns The value from the previous render.
 */
export function usePrevious<T>(value: T): T | undefined {
  // FIX: Explicitly initialize useRef with `undefined`. While `useRef<T>()` is valid,
  // some build tools might incorrectly flag it as an error. This change makes the
  // initialization explicit, resolving the "Expected 1 arguments, but got 0" error.
  const ref = useRef<T | undefined>(undefined);
  useEffect(() => {
    ref.current = value;
  }, [value]);
  return ref.current;
}
